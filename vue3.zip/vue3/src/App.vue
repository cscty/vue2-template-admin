<template>
  <div>
    <div>
      <button>前往首页</button>
      <router-link to="/vue">vue应用</router-link>
    </div>
    <router-view></router-view>
    <div id="vue-app"></div>
    <h1>间隔</h1>
    <div>
      <router-link :to="{ path: '/' }">首页</router-link>
      <router-link to="/vue2">vue应用</router-link>
    </div>
    <router-view></router-view>
    <div id="vue2"></div>
  </div>
</template>

<script>
import A from 'vue2/vue2'
export default {
  mounted() {
    console.log(A)
  },
}
</script>
<style>
#app {
  color: red !important;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
