import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// main.js
import { registerMicroApps, start } from 'qiankun'
createApp(App).use(store).use(router).mount('#app')

registerMicroApps([
  {
    // 微应用的名称
    name: 'vue2',
    // 微应用的入口
    entry: 'http://manager.bilibili.co:5000/',
    // 微应用的容器节点的选择器
    container: '#vue2',
    // 微应用的激活规则
    activeRule: ['/vue2'],
    props: {
      displayMenu: true,
    },
  },
])
start()
