// 设置代理对象
const proxyConfig = {
  target: 'http://uat-manager.bilibili.co',
  changeOrigin: true,
  onProxyReq(proxyReq) {
    proxyReq.setHeader('Referer', 'http://uat-manager.bilibili.co')
    proxyReq.setHeader('Origin', 'http://uat-manager.bilibili.co')
  },
}
const { ModuleFederationPlugin } = require('webpack').container

module.exports = {
  devServer: {
    port: 3001,
    host: 'manager.bilibili.co',
    proxy: {
      '/x/': proxyConfig,
    },
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  },
  configureWebpack: {
    plugins: [
      new ModuleFederationPlugin({
        name: 'vue_app',
        filename: 'vue_app.js',
        remotes: {
          vue2: 'vue2@http://localhost:5000/vue2.js',
        },
      }),
    ],
  },
}
